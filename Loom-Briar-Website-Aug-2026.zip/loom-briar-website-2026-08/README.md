# Loom Briar Website — August 2026 Update

This package is a clean, static GitHub Pages–ready version of the Loom Briar website.

## Included updates

- Enchanted Briar Woods entrance gate
- Premium woodland / moonlight / moss visual direction
- Preferred tagline: **“A world woven from moonlight, moss, and imagination.”**
- Pawdrey as the spirit/mascot of the Briar Woods
- Pawdrey placeholder reflects her gray dilute tortie look, clipped left ear, and upside-down moon forehead mark
- Thermochromic explanation with the note that the fastest transformation happens in hot sunlight
- Featured keepsakes:
  - Secret Bloom — $89.99
  - Lunastray — $89.99
  - Ocean Paws — $89.99
- PayPal buttons using `https://paypal.me/loombriar`
- Contact email: `loombriar@gmail.com`
- Product-photo layout designed to preserve original product photography instead of regenerating or altering the artwork
- Responsive mobile navigation
- Reduced-motion accessibility support
- No Jekyll requirement
- `.nojekyll` included for straightforward GitHub Pages hosting

## Add your real product photos

Place the original photographs here:

- `assets/products/secret-bloom.jpg`
- `assets/products/lunastray.jpg`
- `assets/products/ocean-paws.jpg`

The site automatically uses the styled placeholder if an image is missing. Once a real image with the matching filename is present, it replaces the placeholder.

## Add the approved Pawdrey logo

Place your approved round Pawdrey logo at:

`assets/pawdrey-logo.png`

The current CSS illustration is intentionally a placeholder. It does not claim to reproduce your approved logo.

## Etsy links

The exact Etsy listing URLs were not available when this package was generated, so the Etsy buttons are intentionally disabled instead of pointing to a made-up URL.

To activate one:
1. Open `index.html`.
2. Find `class="button ghost etsy-link"`.
3. Replace `href="#"` with the real listing URL.
4. Remove `aria-disabled="true"`.

## GitHub Pages

Upload the **contents of this folder** to the root of your repository.

Then in GitHub:

1. Repository **Settings**
2. **Pages**
3. Build and deployment → **Deploy from a branch**
4. Branch: **main**
5. Folder: **/(root)**
6. Save

`index.html` must remain in the repository root.

## Custom domain

If you later use a custom domain, create a file named `CNAME` in the repository root containing only the domain name.

## Files

- `index.html` — site content
- `style.css` — full visual design
- `script.js` — entrance gate, menu, reveal effects, image fallback
- `.nojekyll` — prevents unnecessary Jekyll processing
- `404.html` — friendly fallback page
- `assets/` — logo and original product-photo locations

## Important

This package intentionally does not invent missing product photos, Etsy URLs, or a final Pawdrey logo file. Those should be your real approved assets.
