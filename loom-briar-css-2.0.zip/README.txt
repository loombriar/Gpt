Replace your current style.css with this file. No HTML or JavaScript changes are required.
Keep the existing assets folder and filenames unchanged.
